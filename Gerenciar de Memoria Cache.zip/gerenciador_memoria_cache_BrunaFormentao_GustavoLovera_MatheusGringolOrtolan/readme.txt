O presente programa foi desenvolvido por:
- Bruna Forment�o
- Gustavo Lovera
- Matheus Gringol Ortolan

Desenvolvido em HTML, CSS e Javascript. Necess�rio abrir o arquivo TrabalhoMemoriaCache

O funcionamento do programa ocorre da seguinte forma:
- O usu�rio tem 2 op��es no menu de op��es, ent�o ele pode escolher entre Ler da Mem�ria e Escrever na Mem�ria. 
Tamb�m tem a op��o de ver as estat�sticas das movimenta��es.
- Ao escolher a op��o Ler da Mem�ria, o programa ir� retornar a vari�vel que se encontra alocada na mem�ria. Al�m de escrever tais dados na mem�ria cache, 
caso o endere�o da mem�ria n�o esteja em cache.
- Caso o usu�rio escolha Escrever na Mem�ria, ele deve informar o endere�o da mem�ria no qual ele deseja inserir a informa��o. Ap�s isso, � feita a escrita 
- As estat�sticas mostram ao usu�rio o Numero de Acessos, Numero de Acertos, Numero de Faltas, Numero de Leituras, Numero de Escritas, 
Numero de Acertos na Leitura, Numero de Acertos na Escrita, Numero de Faltas na Leitura, Numero de Faltas na Escrita.
